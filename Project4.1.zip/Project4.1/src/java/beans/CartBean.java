package beans;

import com.myapp.struts.*;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sogourgo
 */
public class CartBean implements java.io.Serializable {

    private String coffee, sugar, water;
    private double total;
    Prices sofia = new Prices();
    double price1;
    double price2;
    double price3;
    double coffee1;
    double sugar1;
    double water1;

    public CartBean() {

        coffee = "0";
        sugar = "0";
        water = "0";
        coffee1 = 0;
        sugar1 = 0;
        water1 = 0;

        //Quantity = "0";
        total = 0;
        sofia.prices();
        price1 = sofia.getprice1();
        price2 = sofia.getprice2();
        price3 = sofia.getprice3();

    }

    public String getCoffee() {
        if (LoginAction.Temp.flag1 == 1) {
            this.coffee = "0";
        }
        LoginAction.Temp.flag1 = 0;
        return this.coffee;
    }

    public void setCoffee(final String coffee) {
        this.coffee = coffee;
    }

    public String getSugar() {
        if (LoginAction.Temp.flag2 == 1) {
            this.sugar = "0";
        }
        LoginAction.Temp.flag2 = 0;
        return this.sugar;
    }

    public void setSugar(final String sugar) {
        this.sugar = sugar;
    }

    public String getWater() {
        if (LoginAction.Temp.flag3 == 1) {
            this.water = "0";
        }
        LoginAction.Temp.flag3 = 0;
        return this.water;
    }

    public void setWater(final String water) {
        this.water = water;
    }

    public double getCoffee1() {

        return this.coffee1 = Double.parseDouble(this.coffee) * price1;

    }

    public double getSugar1() {

        return this.sugar1 = Double.parseDouble(this.sugar) * price1;

    }

    public double getWater1() {

        return this.water1 = Double.parseDouble(this.water) * price1;

    }

    public double getTotal() {
        this.coffee1 = Double.parseDouble(this.coffee) * price1;
        this.sugar1 = Double.parseDouble(this.sugar) * price2;
        this.water1 = Double.parseDouble(this.water) * price3;
        return this.total = this.coffee1 + this.sugar1 + this.water1;
    }

    public double getPrice1() {
        return this.price1;
    }

    public double getPrice2() {
        return this.price2;
    }

    public double getPrice3() {
        return this.price3;
    }
}