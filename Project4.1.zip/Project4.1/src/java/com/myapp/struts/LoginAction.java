/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.struts;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 *
 * @author Spyros
 */
public class LoginAction extends org.apache.struts.action.Action {
    
    public static class Temp {

        public static int flag1, flag2, flag3;
        // public int getFlag(){
        //  return flag;
        //}
    }

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private final static String FAILURE = "failure";
    private final static String CART = "cart";
    private final static String CART2 = "cart2";

    /**
     * This is the action called from the Struts framework.
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        // extract user data
        LoginForm formBean = (LoginForm) form;
        String name = formBean.getName();
        String email = formBean.getEmail();

// perform validation
        if ((name == null) || // name parameter does not exist
                email == null || // email parameter does not exist
                name.equals("") || // name parameter is empty
                email.indexOf("@") == -1) {   // email lacks '@'

            formBean.setError();
            return mapping.findForward(FAILURE);
        }
        
        String cookieName = "u";
        String sofia1 = "";
        Cookie cookies[] = request.getCookies();
        Cookie myCookie = null;
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                myCookie = cookies[i];
                if (cookies[i].getName().equals(cookieName)) {
                    sofia1 = myCookie.getValue();
                    break;
                }
            }
        }
        Cookie cookie = null;
        cookie = new Cookie("u", formBean.getName());
        //cookie = new Cookie("u","sofia");
        response.addCookie(cookie);
        //Temp temp1 = new Temp();

        if (sofia1 == null) {
            Temp.flag1 = 1;
            Temp.flag2 = 1;
            Temp.flag3 = 1;

        } else {
            if (!sofia1.equalsIgnoreCase(name)) {
                Temp.flag1 = 1;
                Temp.flag2 = 1;
                Temp.flag3 = 1;
            } else {
                Temp.flag1 = 0;
                Temp.flag2 = 0;
                Temp.flag3 = 0;
                
            }
        }

        //return mapping.findForward(SUCCESS);
        //return mapping.findForward(CART);
        return mapping.findForward(CART2);
    }
}
